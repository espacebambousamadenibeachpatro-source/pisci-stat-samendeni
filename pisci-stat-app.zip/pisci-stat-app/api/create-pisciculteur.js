import { createClient } from "@supabase/supabase-js";

// Client "admin" — clé service, UNIQUEMENT côté serveur (jamais dans le navigateur)
const admin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Méthode non autorisée" });
  }

  const authHeader = req.headers.authorization || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "Non authentifié" });

  // Vérifie que l'appelant est bien connecté...
  const { data: userData, error: userErr } = await admin.auth.getUser(token);
  if (userErr || !userData?.user) return res.status(401).json({ error: "Session invalide" });

  // ...et qu'il a le rôle admin
  const { data: profile } = await admin
    .from("profiles")
    .select("role")
    .eq("id", userData.user.id)
    .single();
  if (!profile || profile.role !== "admin") {
    return res.status(403).json({ error: "Réservé à l'administrateur" });
  }

  const { identifiant, motDePasse, nom, prenom, sexe, telephone, email, adresse, organisation, anneeDebut } = req.body || {};
  if (!identifiant || !motDePasse || !nom || !prenom) {
    return res.status(400).json({ error: "Champs requis manquants" });
  }

  const fakeEmail = `${identifiant.trim().toLowerCase()}@piscistat.local`;

  // 1. Crée le compte d'authentification
  const { data: created, error: createErr } = await admin.auth.admin.createUser({
    email: fakeEmail,
    password: motDePasse,
    email_confirm: true,
  });
  if (createErr) return res.status(400).json({ error: createErr.message });

  // 2. Crée la fiche pisciculteur
  const { data: pisc, error: piscErr } = await admin
    .from("pisciculteurs")
    .insert({
      identifiant: identifiant.trim().toLowerCase(),
      nom, prenom, sexe, telephone, email, adresse, organisation,
      annee_debut: anneeDebut,
    })
    .select()
    .single();
  if (piscErr) {
    await admin.auth.admin.deleteUser(created.user.id);
    return res.status(400).json({ error: piscErr.message });
  }

  // 3. Lie le compte auth au profil applicatif
  const { error: profileErr } = await admin.from("profiles").insert({
    id: created.user.id,
    role: "pisciculteur",
    pisciculteur_id: pisc.id,
  });
  if (profileErr) return res.status(400).json({ error: profileErr.message });

  return res.status(200).json({ pisciculteur: pisc });
}
