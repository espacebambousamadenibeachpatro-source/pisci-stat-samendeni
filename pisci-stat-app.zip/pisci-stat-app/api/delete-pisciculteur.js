import { createClient } from "@supabase/supabase-js";

const admin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Méthode non autorisée" });

  const token = (req.headers.authorization || "").replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "Non authentifié" });

  const { data: userData, error: userErr } = await admin.auth.getUser(token);
  if (userErr || !userData?.user) return res.status(401).json({ error: "Session invalide" });

  const { data: profile } = await admin.from("profiles").select("role").eq("id", userData.user.id).single();
  if (!profile || profile.role !== "admin") return res.status(403).json({ error: "Réservé à l'administrateur" });

  const { pisciculteurId } = req.body || {};
  if (!pisciculteurId) return res.status(400).json({ error: "pisciculteurId manquant" });

  const { data: linkedProfile } = await admin
    .from("profiles")
    .select("id")
    .eq("pisciculteur_id", pisciculteurId)
    .maybeSingle();

  await admin.from("pisciculteurs").delete().eq("id", pisciculteurId); // cascade cages + profile

  if (linkedProfile?.id) {
    await admin.auth.admin.deleteUser(linkedProfile.id);
  }

  return res.status(200).json({ ok: true });
}
