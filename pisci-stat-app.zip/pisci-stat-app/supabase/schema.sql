-- ============================================================
-- Schéma PisciStat Samendéni — à exécuter dans Supabase
-- (Dashboard Supabase > SQL Editor > coller > Run)
-- ============================================================

create extension if not exists "pgcrypto";

-- ---------- Organisations ----------
create table if not exists organisations (
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  localite text,
  membres integer,
  responsable text,
  contact text,
  created_at timestamptz default now()
);

-- ---------- Pisciculteurs ----------
create table if not exists pisciculteurs (
  id uuid primary key default gen_random_uuid(),
  identifiant text unique not null,
  nom text not null,
  prenom text not null,
  sexe text,
  telephone text,
  email text,
  adresse text,
  organisation text,
  annee_debut text,
  created_at timestamptz default now()
);

-- ---------- Cages ----------
create table if not exists cages (
  id uuid primary key default gen_random_uuid(),
  pisciculteur_id uuid references pisciculteurs(id) on delete cascade,
  type text not null,
  nombre integer default 1,
  nombre_alevins integer,
  taille_alevins text,
  date_empoissonnement date,
  date_recolte date,
  statut text default 'En production',
  created_at timestamptz default now()
);

-- ---------- Journal des modifications ----------
create table if not exists journal (
  id uuid primary key default gen_random_uuid(),
  text text not null,
  created_at timestamptz default now()
);

-- ---------- Profils (lien entre auth.users et rôle applicatif) ----------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin', 'pisciculteur')),
  pisciculteur_id uuid references pisciculteurs(id) on delete cascade,
  created_at timestamptz default now()
);

-- ---------- Fonction utilitaire : suis-je admin ? ----------
create or replace function is_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from profiles where id = auth.uid() and role = 'admin'
  );
$$;

-- ---------- Fonction utilitaire : mon pisciculteur_id ----------
create or replace function my_pisciculteur_id()
returns uuid
language sql
security definer
stable
as $$
  select pisciculteur_id from profiles where id = auth.uid();
$$;

-- ============================================================
-- RLS
-- ============================================================
alter table organisations enable row level security;
alter table pisciculteurs enable row level security;
alter table cages enable row level security;
alter table journal enable row level security;
alter table profiles enable row level security;

-- profiles : chacun lit son propre profil, l'admin lit tout
create policy "profiles_select_own_or_admin" on profiles
  for select using (id = auth.uid() or is_admin());

-- organisations : admin CRUD complet, pisciculteur lecture seule
create policy "organisations_select_all" on organisations
  for select using (auth.uid() is not null);
create policy "organisations_admin_write" on organisations
  for insert with check (is_admin());
create policy "organisations_admin_update" on organisations
  for update using (is_admin());
create policy "organisations_admin_delete" on organisations
  for delete using (is_admin());

-- pisciculteurs : admin CRUD complet, pisciculteur voit/modifie sa propre fiche
create policy "pisciculteurs_select" on pisciculteurs
  for select using (is_admin() or id = my_pisciculteur_id());
create policy "pisciculteurs_admin_insert" on pisciculteurs
  for insert with check (is_admin());
create policy "pisciculteurs_update" on pisciculteurs
  for update using (is_admin() or id = my_pisciculteur_id());
create policy "pisciculteurs_admin_delete" on pisciculteurs
  for delete using (is_admin());

-- cages : admin CRUD complet, pisciculteur CRUD sur ses propres cages
create policy "cages_select" on cages
  for select using (is_admin() or pisciculteur_id = my_pisciculteur_id());
create policy "cages_insert" on cages
  for insert with check (is_admin() or pisciculteur_id = my_pisciculteur_id());
create policy "cages_update" on cages
  for update using (is_admin() or pisciculteur_id = my_pisciculteur_id());
create policy "cages_delete" on cages
  for delete using (is_admin() or pisciculteur_id = my_pisciculteur_id());

-- journal : admin uniquement (lecture + écriture)
create policy "journal_admin_select" on journal
  for select using (is_admin());
create policy "journal_insert" on journal
  for insert with check (auth.uid() is not null);

-- ============================================================
-- Après avoir créé votre premier utilisateur admin dans
-- Authentication > Users (email + mot de passe), récupérez son
-- UUID et exécutez :
--
-- insert into profiles (id, role) values ('UUID-DE-VOTRE-COMPTE', 'admin');
-- ============================================================
