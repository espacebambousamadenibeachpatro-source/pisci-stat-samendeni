import React, { useState, useEffect } from "react";
import {
  LayoutDashboard, Users, Grid3x3, Building2, BarChart3, Settings,
  Plus, Search, Pencil, Trash2, X, Download, Calendar, Phone, Mail,
  MapPin, Lock, UserCircle2, AlertCircle, LogOut,
} from "lucide-react";
import { supabase, identifiantToEmail } from "./lib/supabaseClient";

/* ---------- design tokens ---------- */
const C = {
  deep: "#08302E", mid: "#12524F", accent: "#D9A441", accentDark: "#B8842A",
  sand: "#EDE8D6", sandDeep: "#E1DAC2", ink: "#0E211F", green: "#4C9A6A",
  red: "#B4523F", line: "#CFC6A6",
};

const CAGE_TYPES = ["75", "100", "125", "200-250", "+250"];
const CAGE_LABELS = { "75": "75 m³", "100": "100 m³", "125": "125 m³", "200-250": "200–250 m³", "+250": "+250 m³" };
const STATUTS = ["En production", "Récoltée"];
const MONTHS_FR = ["Jan","Fév","Mar","Avr","Mai","Jun","Jul","Aoû","Sep","Oct","Nov","Déc"];
const todayISO = () => new Date().toISOString().slice(0, 10);

/* ---------- shared UI ---------- */
function Field({ label, children }) {
  return (
    <label className="block mb-3">
      <span className="block text-xs mb-1 tracking-wide" style={{ color: C.mid, fontFamily: "'IBM Plex Mono', monospace" }}>
        {label.toUpperCase()}
      </span>
      {children}
    </label>
  );
}
const inputStyle = { width: "100%", padding: "10px 12px", borderRadius: 8, border: `1.5px solid ${C.line}`, background: "#FFFDF7", color: C.ink, fontFamily: "'Inter', sans-serif", fontSize: 15, outline: "none" };
function TextInput(props) { return <input {...props} style={inputStyle} />; }
function Select({ children, ...props }) { return <select {...props} style={inputStyle}>{children}</select>; }
function Button({ children, variant = "primary", onClick, style, disabled }) {
  const base = { padding: "10px 16px", borderRadius: 8, fontWeight: 600, fontSize: 14, fontFamily: "'Inter', sans-serif", cursor: disabled ? "not-allowed" : "pointer", border: "none", display: "inline-flex", alignItems: "center", gap: 6, opacity: disabled ? 0.6 : 1 };
  const variants = {
    primary: { background: C.accent, color: C.ink },
    dark: { background: C.deep, color: C.sand },
    ghost: { background: "transparent", color: C.mid, border: `1.5px solid ${C.line}` },
    danger: { background: "transparent", color: C.red, border: `1.5px solid ${C.red}` },
  };
  return <button onClick={onClick} disabled={disabled} style={{ ...base, ...variants[variant], ...style }}>{children}</button>;
}
function Modal({ title, onClose, children }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(8,48,46,0.55)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 50 }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{ background: C.sand, width: "100%", maxWidth: 480, maxHeight: "88vh", overflowY: "auto", borderRadius: "18px 18px 0 0", padding: 20 }}>
        <div className="flex items-center justify-between mb-4">
          <h3 style={{ fontFamily: "'Fraunces', serif", fontSize: 20, color: C.deep }}>{title}</h3>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer" }}><X size={22} color={C.mid} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
function StatCard({ label, value, sub }) {
  return (
    <div style={{ background: C.deep, borderRadius: 14, padding: "16px 18px", flex: "1 1 140px", backgroundImage: "repeating-linear-gradient(0deg, rgba(217,164,65,0.06) 0px, rgba(217,164,65,0.06) 1px, transparent 1px, transparent 9px), repeating-linear-gradient(90deg, rgba(217,164,65,0.06) 0px, rgba(217,164,65,0.06) 1px, transparent 1px, transparent 9px)" }}>
      <div style={{ color: C.sand, opacity: 0.75, fontSize: 12, fontFamily: "'IBM Plex Mono', monospace", letterSpacing: 0.5 }}>{label.toUpperCase()}</div>
      <div style={{ color: C.accent, fontSize: 28, fontFamily: "'Fraunces', serif", fontWeight: 600, marginTop: 2 }}>{value}</div>
      {sub && <div style={{ color: C.sand, opacity: 0.6, fontSize: 12, marginTop: 2 }}>{sub}</div>}
    </div>
  );
}
function SectionCard({ title, children }) {
  return (
    <div style={{ background: "#fff", borderRadius: 14, padding: 16, marginBottom: 16, border: `1px solid ${C.line}` }}>
      <p style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: C.mid, marginBottom: 10 }}>{title.toUpperCase()}</p>
      {children}
    </div>
  );
}
function Bar({ label, value, max }) {
  return (
    <div className="flex items-center gap-2 mb-2">
      <span style={{ width: 100, fontSize: 12.5, color: C.ink, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</span>
      <div style={{ flex: 1, background: C.sandDeep, borderRadius: 6, height: 10, overflow: "hidden" }}>
        <div style={{ width: `${(value / max) * 100}%`, background: C.mid, height: "100%" }} />
      </div>
      <span style={{ fontSize: 12.5, width: 22, textAlign: "right", color: C.mid }}>{value}</span>
    </div>
  );
}
function Empty() { return <p style={{ fontSize: 13, color: C.mid, opacity: 0.7 }}>Aucune donnée pour le moment.</p>; }
function NavBtn({ icon: Icon, label, active, onClick }) {
  return (
    <button onClick={onClick} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, color: active ? C.accent : "#8FADA9", padding: "2px 6px" }}>
      <Icon size={20} /><span style={{ fontSize: 10 }}>{label}</span>
    </button>
  );
}
function exportCSV(filename, rows) {
  if (!rows.length) return;
  const headers = Object.keys(rows[0]);
  const csv = [headers.join(";"), ...rows.map(r => headers.map(h => `"${String(r[h] ?? "").replace(/"/g, '""')}"`).join(";"))].join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

/* ============================================================ */
export default function App() {
  const [session, setSession] = useState(undefined); // undefined = loading, null = logged out
  const [profile, setProfile] = useState(null);
  const [tab, setTab] = useState("dashboard");
  const [loginError, setLoginError] = useState("");

  const [pisciculteurs, setPisciculteurs] = useState([]);
  const [cages, setCages] = useState([]);
  const [organisations, setOrganisations] = useState([]);
  const [journal, setJournal] = useState([]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, sess) => setSession(sess));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session === undefined) return;
    if (!session) { setProfile(null); return; }
    (async () => {
      const { data } = await supabase.from("profiles").select("*").eq("id", session.user.id).single();
      setProfile(data || null);
    })();
  }, [session]);

  async function refreshAll() {
    const [{ data: p }, { data: c }, { data: o }, { data: j }] = await Promise.all([
      supabase.from("pisciculteurs").select("*").order("created_at", { ascending: false }),
      supabase.from("cages").select("*").order("created_at", { ascending: false }),
      supabase.from("organisations").select("*").order("nom"),
      profile?.role === "admin"
        ? supabase.from("journal").select("*").order("created_at", { ascending: false }).limit(50)
        : Promise.resolve({ data: [] }),
    ]);
    setPisciculteurs(p || []); setCages(c || []); setOrganisations(o || []); setJournal(j || []);
  }

  useEffect(() => { if (profile) refreshAll(); }, [profile]);

  async function logAction(text) {
    await supabase.from("journal").insert({ text });
    if (profile?.role === "admin") refreshAll();
  }

  async function login(identifiant, motDePasse, wantedRole) {
    const email = wantedRole === "admin" ? identifiant.trim() : identifiantToEmail(identifiant);
    const { error } = await supabase.auth.signInWithPassword({ email, password: motDePasse });
    if (error) { setLoginError("Identifiant ou mot de passe incorrect."); return; }
    setLoginError("");
  }
  async function logout() { await supabase.auth.signOut(); setTab("dashboard"); }

  /* ---- pisciculteurs ---- */
  async function addPisciculteur(f) {
    const { data: { session: s } } = await supabase.auth.getSession();
    const res = await fetch("/api/create-pisciculteur", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${s.access_token}` },
      body: JSON.stringify(f),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Erreur lors de la création");
    await logAction(`Ajout pisciculteur : ${f.prenom} ${f.nom}`);
    refreshAll();
  }
  async function updatePisciculteur(f) {
    const { id, identifiant, nom, prenom, sexe, telephone, email, adresse, organisation, anneeDebut } = f;
    const { error } = await supabase.from("pisciculteurs").update({
      nom, prenom, sexe, telephone, email, adresse, organisation, annee_debut: anneeDebut,
    }).eq("id", id);
    if (error) throw new Error(error.message);
    await logAction(`Modification pisciculteur : ${prenom} ${nom}`);
    refreshAll();
  }
  async function deletePisciculteur(id) {
    const p = pisciculteurs.find(x => x.id === id);
    const { data: { session: s } } = await supabase.auth.getSession();
    const res = await fetch("/api/delete-pisciculteur", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${s.access_token}` },
      body: JSON.stringify({ pisciculteurId: id }),
    });
    if (!res.ok) { const b = await res.json(); alert(b.error || "Erreur"); return; }
    if (p) await logAction(`Suppression pisciculteur : ${p.prenom} ${p.nom}`);
    refreshAll();
  }

  /* ---- cages ---- */
  async function saveCage(c) {
    const row = {
      pisciculteur_id: c.pisciculteurId, type: c.type, nombre: c.nombre,
      nombre_alevins: c.nombreAlevins || null, taille_alevins: c.tailleAlevins,
      date_empoissonnement: c.dateEmpoissonnement || null, date_recolte: c.dateRecolte || null,
      statut: c.statut,
    };
    if (c.id) {
      const { error } = await supabase.from("cages").update(row).eq("id", c.id);
      if (error) throw new Error(error.message);
      await logAction(`Modification cage (${CAGE_LABELS[c.type]})`);
    } else {
      const { error } = await supabase.from("cages").insert(row);
      if (error) throw new Error(error.message);
      await logAction(`Ajout cage (${CAGE_LABELS[c.type]})`);
    }
    refreshAll();
  }
  async function deleteCage(id) {
    await supabase.from("cages").delete().eq("id", id);
    await logAction("Suppression d'une cage");
    refreshAll();
  }

  /* ---- organisations ---- */
  async function saveOrg(o) {
    const row = { nom: o.nom, localite: o.localite, membres: o.membres || null, responsable: o.responsable, contact: o.contact };
    if (o.id) { await supabase.from("organisations").update(row).eq("id", o.id); await logAction(`Modification organisation : ${o.nom}`); }
    else { await supabase.from("organisations").insert(row); await logAction(`Ajout organisation : ${o.nom}`); }
    refreshAll();
  }
  async function deleteOrg(id) {
    const o = organisations.find(x => x.id === id);
    await supabase.from("organisations").delete().eq("id", id);
    if (o) await logAction(`Suppression organisation : ${o.nom}`);
    refreshAll();
  }

  /* ---- loading / login screens ---- */
  if (session === undefined) {
    return <div style={{ minHeight: "100vh", background: C.deep, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <img src="/logo.png" alt="" style={{ width: 64, height: 64 }} />
    </div>;
  }
  if (!session) return <LoginGate onLogin={login} error={loginError} clearError={() => setLoginError("")} />;
  if (!profile) {
    return <div style={{ minHeight: "100vh", background: C.deep, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, padding: 20, textAlign: "center" }}>
      <p style={{ color: C.sand, fontSize: 13 }}>Profil introuvable pour ce compte. Vérifiez qu'une ligne existe dans la table <code>profiles</code>.</p>
      <Button variant="dark" onClick={logout}>Se déconnecter</Button>
    </div>;
  }

  const role = profile.role;
  const me = pisciculteurs.find(p => p.id === profile.pisciculteur_id);
  const visiblePisciculteurs = role === "admin" ? pisciculteurs : pisciculteurs.filter(p => p.id === profile.pisciculteur_id);
  const visibleCages = role === "admin" ? cages : cages.filter(c => c.pisciculteur_id === profile.pisciculteur_id);

  return (
    <div style={{ minHeight: "100vh", background: C.sandDeep, fontFamily: "'Inter', sans-serif", paddingBottom: 76 }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap');`}</style>
      <header style={{ background: C.deep, padding: "18px 18px 22px", borderRadius: "0 0 20px 20px" }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="" style={{ width: 30, height: 30 }} />
            <span style={{ fontFamily: "'Fraunces', serif", color: C.sand, fontSize: 17, fontWeight: 600 }}>PisciStat Samendéni</span>
          </div>
          <button onClick={logout} style={{ background: "none", border: "none", color: C.sand, opacity: 0.75, fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}>
            <LogOut size={13} /> {role === "admin" ? "Administrateur" : "Pisciculteur"}
          </button>
        </div>
      </header>

      <main style={{ padding: "16px 14px", maxWidth: 640, margin: "0 auto" }}>
        {tab === "dashboard" && <Dashboard pisciculteurs={pisciculteurs} cages={cages} />}
        {tab === "pisciculteurs" && role === "admin" && (
          <PisciculteursModule list={pisciculteurs} organisations={organisations} onAdd={addPisciculteur} onUpdate={updatePisciculteur} onDelete={deletePisciculteur} />
        )}
        {tab === "cages" && (
          <CagesModule list={visibleCages} pisciculteurs={visiblePisciculteurs} fixedPisciculteurId={role === "pisciculteur" ? profile.pisciculteur_id : null} onSave={saveCage} onDelete={deleteCage} />
        )}
        {tab === "organisations" && role === "admin" && <OrganisationsModule list={organisations} onSave={saveOrg} onDelete={deleteOrg} />}
        {tab === "stats" && role === "admin" && <StatsModule pisciculteurs={pisciculteurs} cages={cages} organisations={organisations} />}
        {tab === "settings" && role === "admin" && <SettingsModule journal={journal} />}
        {tab === "profil" && role === "pisciculteur" && (
          <div>
            <h2 style={{ fontFamily: "'Fraunces', serif", color: C.deep, fontSize: 22, marginBottom: 14 }}>Mon profil</h2>
            {me && <div style={{ background: "#fff", borderRadius: 14, padding: 16, border: `1px solid ${C.line}` }}>
              <PisciculteurEditForm initial={me} organisations={organisations} onSave={updatePisciculteur} embedded />
              <div style={{ borderTop: `1px solid ${C.line}`, margin: "16px 0" }} />
              <ChangePassword />
            </div>}
          </div>
        )}
      </main>

      <nav style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: C.deep, display: "flex", justifyContent: "space-around", padding: "10px 4px 14px", boxShadow: "0 -4px 14px rgba(0,0,0,0.15)" }}>
        <NavBtn icon={LayoutDashboard} label="Accueil" active={tab === "dashboard"} onClick={() => setTab("dashboard")} />
        {role === "admin" && <NavBtn icon={Users} label="Pisc." active={tab === "pisciculteurs"} onClick={() => setTab("pisciculteurs")} />}
        <NavBtn icon={Grid3x3} label="Cages" active={tab === "cages"} onClick={() => setTab("cages")} />
        {role === "admin" && <NavBtn icon={Building2} label="Orgas" active={tab === "organisations"} onClick={() => setTab("organisations")} />}
        {role === "admin" && <NavBtn icon={BarChart3} label="Stats" active={tab === "stats"} onClick={() => setTab("stats")} />}
        {role === "admin" ? <NavBtn icon={Settings} label="Réglages" active={tab === "settings"} onClick={() => setTab("settings")} /> : <NavBtn icon={Settings} label="Profil" active={tab === "profil"} onClick={() => setTab("profil")} />}
      </nav>
    </div>
  );
}

/* ---------- login ---------- */
function LoginGate({ onLogin, error, clearError }) {
  const [tab, setTab] = useState("pisciculteur");
  const [identifiant, setIdentifiant] = useState("");
  const [motDePasse, setMotDePasse] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (!identifiant || !motDePasse) return;
    setBusy(true);
    await onLogin(identifiant, motDePasse, tab);
    setBusy(false);
  }

  return (
    <div style={{ minHeight: "100vh", background: C.deep, display: "flex", flexDirection: "column", justifyContent: "center", padding: 26 }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Fraunces:wght@600;700&family=Inter:wght@400;500;600&display=swap');`}</style>
      <div className="flex flex-col items-center gap-2 mb-8">
        <img src="/logo.png" alt="PisciStat Samendéni" style={{ width: 92, height: 92, objectFit: "contain" }} />
        <span style={{ fontFamily: "'Fraunces', serif", color: C.sand, fontSize: 24, fontWeight: 700, textAlign: "center" }}>PisciStat Samendéni</span>
      </div>
      <div style={{ background: C.sand, borderRadius: 18, padding: 22 }}>
        <div className="flex mb-5" style={{ background: C.sandDeep, borderRadius: 10, padding: 3 }}>
          {[["pisciculteur", "Pisciculteur"], ["admin", "Administrateur"]].map(([val, label]) => (
            <button key={val} onClick={() => { setTab(val); clearError(); }} style={{ flex: 1, padding: "8px 4px", borderRadius: 8, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600, background: tab === val ? C.deep : "transparent", color: tab === val ? C.sand : C.mid }}>{label}</button>
          ))}
        </div>
        <Field label={tab === "admin" ? "Email" : "Nom d'utilisateur"}>
          <div style={{ position: "relative" }}>
            <UserCircle2 size={16} style={{ position: "absolute", left: 10, top: 12, color: C.mid }} />
            <input value={identifiant} onChange={e => { setIdentifiant(e.target.value); clearError(); }} onKeyDown={e => e.key === "Enter" && submit()} placeholder={tab === "admin" ? "admin@example.com" : "identifiant"} style={{ ...inputStyle, paddingLeft: 32 }} />
          </div>
        </Field>
        <Field label="Mot de passe">
          <div style={{ position: "relative" }}>
            <Lock size={16} style={{ position: "absolute", left: 10, top: 12, color: C.mid }} />
            <input type="password" value={motDePasse} onChange={e => { setMotDePasse(e.target.value); clearError(); }} onKeyDown={e => e.key === "Enter" && submit()} placeholder="••••••••" style={{ ...inputStyle, paddingLeft: 32 }} />
          </div>
        </Field>
        {error && <div className="flex items-center gap-2" style={{ color: C.red, fontSize: 12.5, marginBottom: 12 }}><AlertCircle size={14} /> {error}</div>}
        <Button variant="primary" style={{ width: "100%", justifyContent: "center" }} onClick={submit} disabled={busy}>{busy ? "Connexion…" : "Se connecter"}</Button>
        {tab === "pisciculteur" && <p style={{ fontSize: 11, color: C.mid, opacity: 0.7, marginTop: 12 }}>Vos identifiants vous sont fournis par l'administrateur.</p>}
      </div>
    </div>
  );
}

function ChangePassword() {
  const [pwd, setPwd] = useState("");
  const [msg, setMsg] = useState("");
  async function submit() {
    if (pwd.length < 6) { setMsg("6 caractères minimum."); return; }
    const { error } = await supabase.auth.updateUser({ password: pwd });
    setMsg(error ? error.message : "Mot de passe mis à jour ✓");
    if (!error) setPwd("");
  }
  return (
    <div>
      <p style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11.5, color: C.mid, marginBottom: 10 }}>CHANGER MON MOT DE PASSE</p>
      <Field label="Nouveau mot de passe"><TextInput type="password" value={pwd} onChange={e => setPwd(e.target.value)} /></Field>
      <Button onClick={submit}>Mettre à jour</Button>
      {msg && <p style={{ fontSize: 12, color: C.mid, marginTop: 8 }}>{msg}</p>}
    </div>
  );
}

/* ---------- dashboard ---------- */
function Dashboard({ pisciculteurs, cages }) {
  const totalCages = cages.reduce((s, c) => s + Number(c.nombre || 0), 0);
  const byType = CAGE_TYPES.map(t => ({ type: t, n: cages.filter(c => c.type === t).reduce((s, c) => s + Number(c.nombre || 0), 0) }));
  const upcoming = cages.filter(c => c.date_recolte && c.statut !== "Récoltée").sort((a, b) => new Date(a.date_recolte) - new Date(b.date_recolte)).slice(0, 5);
  const recent = [...pisciculteurs].slice(0, 5);
  return (
    <div>
      <h2 style={{ fontFamily: "'Fraunces', serif", color: C.deep, fontSize: 22, marginBottom: 14 }}>Tableau de bord</h2>
      <div className="flex flex-wrap gap-3 mb-5">
        <StatCard label="Pisciculteurs" value={pisciculteurs.length} />
        <StatCard label="Cages (total)" value={totalCages} />
      </div>
      <SectionCard title="Cages par catégorie">
        {byType.map(b => (
          <div key={b.type} className="flex items-center gap-2 mb-2">
            <span style={{ width: 78, fontSize: 13 }}>{CAGE_LABELS[b.type]}</span>
            <div style={{ flex: 1, background: C.sandDeep, borderRadius: 6, height: 10, overflow: "hidden" }}>
              <div style={{ width: `${Math.min(100, (b.n / Math.max(1, totalCages)) * 100)}%`, background: C.accent, height: "100%" }} />
            </div>
            <span style={{ fontSize: 13, width: 24, textAlign: "right", color: C.mid }}>{b.n}</span>
          </div>
        ))}
      </SectionCard>
      <SectionCard title="Récoltes prévues prochainement">
        {upcoming.length === 0 && <Empty />}
        {upcoming.map(c => (
          <div key={c.id} className="flex items-center justify-between" style={{ padding: "6px 0", borderBottom: `1px solid ${C.line}` }}>
            <span style={{ fontSize: 13 }}>{CAGE_LABELS[c.type]} · {c.nombre} cage(s)</span>
            <span style={{ fontSize: 12, color: C.accentDark, fontFamily: "'IBM Plex Mono', monospace" }}>{c.date_recolte}</span>
          </div>
        ))}
      </SectionCard>
      <SectionCard title="Nouveaux enregistrements">
        {recent.length === 0 && <Empty />}
        {recent.map(p => <div key={p.id} style={{ fontSize: 13, padding: "5px 0" }}>{p.prenom} {p.nom} — {p.organisation || "sans organisation"}</div>)}
      </SectionCard>
    </div>
  );
}

/* ---------- pisciculteurs ---------- */
function slugify(prenom, nom) {
  return `${prenom}.${nom}`.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9.]/g, "");
}
function PisciculteursModule({ list, organisations, onAdd, onUpdate, onDelete }) {
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState(null); // null | {} (new) | pisciculteur (edit)
  const filtered = list.filter(p => `${p.nom} ${p.prenom} ${p.telephone} ${p.organisation}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h2 style={{ fontFamily: "'Fraunces', serif", color: C.deep, fontSize: 22 }}>Pisciculteurs</h2>
        <Button onClick={() => setEditing({})}><Plus size={16} /> Ajouter</Button>
      </div>
      <div style={{ position: "relative", marginBottom: 14 }}>
        <Search size={16} style={{ position: "absolute", left: 10, top: 12, color: C.mid }} />
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Rechercher un pisciculteur…" style={{ ...inputStyle, paddingLeft: 32 }} />
      </div>
      {filtered.map(p => (
        <div key={p.id} style={{ background: "#fff", borderRadius: 12, padding: 14, marginBottom: 10, border: `1px solid ${C.line}` }}>
          <div className="flex items-center justify-between">
            <div>
              <div style={{ fontWeight: 600 }}>{p.prenom} {p.nom} <span style={{ fontSize: 11, color: C.mid }}>({p.sexe}) · @{p.identifiant}</span></div>
              <div style={{ fontSize: 12.5, color: C.mid, marginTop: 3 }}><Phone size={11} style={{ display: "inline", marginRight: 4 }} />{p.telephone || "—"}</div>
              <div style={{ fontSize: 12.5, color: C.mid }}><Mail size={11} style={{ display: "inline", marginRight: 4 }} />{p.email || "—"}</div>
              <div style={{ fontSize: 12.5, color: C.mid }}>{p.organisation || "Sans organisation"} · depuis {p.annee_debut || "—"}</div>
            </div>
            <div className="flex flex-col gap-2">
              <button onClick={() => setEditing(p)} style={{ background: "none", border: "none", cursor: "pointer" }}><Pencil size={16} color={C.mid} /></button>
              <button onClick={() => onDelete(p.id)} style={{ background: "none", border: "none", cursor: "pointer" }}><Trash2 size={16} color={C.red} /></button>
            </div>
          </div>
        </div>
      ))}
      {filtered.length === 0 && <Empty />}
      {editing && !editing.id && <NewPisciculteurForm organisations={organisations} onClose={() => setEditing(null)} onSave={async (f) => { await onAdd(f); setEditing(null); }} />}
      {editing && editing.id && (
        <Modal title="Modifier le pisciculteur" onClose={() => setEditing(null)}>
          <PisciculteurEditForm initial={editing} organisations={organisations} onSave={async (f) => { await onUpdate(f); setEditing(null); }} onClose={() => setEditing(null)} />
        </Modal>
      )}
    </div>
  );
}
function NewPisciculteurForm({ organisations, onClose, onSave }) {
  const [f, setF] = useState({ nom: "", prenom: "", sexe: "Homme", telephone: "", email: "", adresse: "", organisation: "", anneeDebut: "", identifiant: "", motDePasse: "" });
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  async function handleSave() {
    if (!f.nom || !f.prenom) return setErr("Le nom et le prénom sont requis.");
    const identifiant = (f.identifiant || slugify(f.prenom, f.nom)).trim().toLowerCase();
    if (!f.motDePasse || f.motDePasse.length < 6) return setErr("Mot de passe : 6 caractères minimum.");
    setErr(""); setBusy(true);
    try { await onSave({ ...f, identifiant }); }
    catch (e) { setErr(e.message); }
    setBusy(false);
  }
  return (
    <Modal title="Ajouter un pisciculteur" onClose={onClose}>
      <Field label="Nom"><TextInput value={f.nom} onChange={set("nom")} /></Field>
      <Field label="Prénom(s)"><TextInput value={f.prenom} onChange={set("prenom")} /></Field>
      <Field label="Sexe"><Select value={f.sexe} onChange={set("sexe")}><option>Homme</option><option>Femme</option></Select></Field>
      <Field label="Téléphone"><TextInput value={f.telephone} onChange={set("telephone")} /></Field>
      <Field label="Email"><TextInput type="email" value={f.email} onChange={set("email")} /></Field>
      <Field label="Adresse"><TextInput value={f.adresse} onChange={set("adresse")} /></Field>
      <Field label="Organisation">
        <Select value={f.organisation} onChange={set("organisation")}>
          <option value="">— Aucune —</option>
          {organisations.map(o => <option key={o.id} value={o.nom}>{o.nom}</option>)}
        </Select>
      </Field>
      <Field label="Année de début d'activité"><TextInput type="number" value={f.anneeDebut} onChange={set("anneeDebut")} /></Field>
      <div style={{ borderTop: `1px solid ${C.line}`, margin: "14px 0 10px" }} />
      <p style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11.5, color: C.mid, marginBottom: 10 }}>ACCÈS À L'APPLICATION</p>
      <Field label="Nom d'utilisateur"><TextInput value={f.identifiant} onChange={set("identifiant")} placeholder={slugify(f.prenom || "prenom", f.nom || "nom")} /></Field>
      <Field label="Mot de passe"><TextInput value={f.motDePasse} onChange={set("motDePasse")} placeholder="6 caractères minimum" /></Field>
      {err && <div className="flex items-center gap-2" style={{ color: C.red, fontSize: 12.5, marginBottom: 10 }}><AlertCircle size={14} /> {err}</div>}
      <div className="flex gap-2 mt-3">
        <Button onClick={handleSave} disabled={busy} style={{ flex: 1, justifyContent: "center" }}>{busy ? "…" : "Enregistrer"}</Button>
        <Button variant="ghost" onClick={onClose} style={{ flex: 1, justifyContent: "center" }}>Annuler</Button>
      </div>
    </Modal>
  );
}
function PisciculteurEditForm({ initial, organisations, onSave, onClose, embedded }) {
  const [f, setF] = useState({ ...initial, anneeDebut: initial.annee_debut });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  async function handleSave() { setBusy(true); await onSave(f); setBusy(false); }
  return (
    <>
      <Field label="Nom"><TextInput value={f.nom} onChange={set("nom")} /></Field>
      <Field label="Prénom(s)"><TextInput value={f.prenom} onChange={set("prenom")} /></Field>
      <Field label="Sexe"><Select value={f.sexe} onChange={set("sexe")}><option>Homme</option><option>Femme</option></Select></Field>
      <Field label="Téléphone"><TextInput value={f.telephone} onChange={set("telephone")} /></Field>
      <Field label="Email"><TextInput type="email" value={f.email} onChange={set("email")} /></Field>
      <Field label="Adresse"><TextInput value={f.adresse} onChange={set("adresse")} /></Field>
      <Field label="Organisation">
        <Select value={f.organisation || ""} onChange={set("organisation")}>
          <option value="">— Aucune —</option>
          {organisations.map(o => <option key={o.id} value={o.nom}>{o.nom}</option>)}
        </Select>
      </Field>
      <Field label="Année de début d'activité"><TextInput type="number" value={f.anneeDebut || ""} onChange={set("anneeDebut")} /></Field>
      <div className="flex gap-2 mt-3">
        <Button onClick={handleSave} disabled={busy} style={{ flex: 1, justifyContent: "center" }}>{busy ? "…" : "Enregistrer"}</Button>
        {!embedded && <Button variant="ghost" onClick={onClose} style={{ flex: 1, justifyContent: "center" }}>Annuler</Button>}
      </div>
    </>
  );
}

/* ---------- cages ---------- */
function CagesModule({ list, pisciculteurs, fixedPisciculteurId, onSave, onDelete }) {
  const [editing, setEditing] = useState(null);
  const nameOf = (id) => { const p = pisciculteurs.find(x => x.id === id); return p ? `${p.prenom} ${p.nom}` : "—"; };
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h2 style={{ fontFamily: "'Fraunces', serif", color: C.deep, fontSize: 22 }}>Cages</h2>
        <Button onClick={() => setEditing({ pisciculteurId: fixedPisciculteurId || "", statut: "En production", dateEmpoissonnement: todayISO() })}><Plus size={16} /> Ajouter</Button>
      </div>
      {list.map(c => (
        <div key={c.id} style={{ background: "#fff", borderRadius: 12, padding: 14, marginBottom: 10, border: `1px solid ${C.line}` }}>
          <div className="flex items-center justify-between">
            <div>
              <div style={{ fontWeight: 600 }}>{CAGE_LABELS[c.type]} · {c.nombre} cage(s)</div>
              <div style={{ fontSize: 12.5, color: C.mid }}>{nameOf(c.pisciculteur_id)}</div>
              <div style={{ fontSize: 12.5, color: C.mid }}>{c.nombre_alevins || 0} alevins · {c.taille_alevins || "—"}</div>
              <div style={{ fontSize: 12.5, color: C.mid }}><Calendar size={11} style={{ display: "inline", marginRight: 4 }} />Empoiss. {c.date_empoissonnement || "—"} → Récolte {c.date_recolte || "—"}</div>
              <span style={{ display: "inline-block", marginTop: 4, fontSize: 11, padding: "2px 8px", borderRadius: 20, background: c.statut === "Récoltée" ? "#E4F0E7" : "#FBF0DA", color: c.statut === "Récoltée" ? C.green : C.accentDark }}>{c.statut}</span>
            </div>
            <div className="flex flex-col gap-2">
              <button onClick={() => setEditing({ ...c, pisciculteurId: c.pisciculteur_id, nombreAlevins: c.nombre_alevins, tailleAlevins: c.taille_alevins, dateEmpoissonnement: c.date_empoissonnement, dateRecolte: c.date_recolte })} style={{ background: "none", border: "none", cursor: "pointer" }}><Pencil size={16} color={C.mid} /></button>
              <button onClick={() => onDelete(c.id)} style={{ background: "none", border: "none", cursor: "pointer" }}><Trash2 size={16} color={C.red} /></button>
            </div>
          </div>
        </div>
      ))}
      {list.length === 0 && <Empty />}
      {editing && <CageForm initial={editing} pisciculteurs={pisciculteurs} lockPisciculteur={!!fixedPisciculteurId} onClose={() => setEditing(null)} onSave={async (c) => { await onSave(c); setEditing(null); }} />}
    </div>
  );
}
function CageForm({ initial, pisciculteurs, lockPisciculteur, onClose, onSave }) {
  const [f, setF] = useState({ pisciculteurId: "", type: "100", nombre: 1, nombreAlevins: "", tailleAlevins: "", dateEmpoissonnement: todayISO(), dateRecolte: "", statut: "En production", ...initial });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  async function handleSave() { if (!f.pisciculteurId) return; setBusy(true); await onSave(f); setBusy(false); }
  return (
    <Modal title={initial.id ? "Modifier la cage" : "Ajouter une cage"} onClose={onClose}>
      <Field label="Pisciculteur">
        <Select value={f.pisciculteurId} onChange={set("pisciculteurId")} disabled={lockPisciculteur}>
          <option value="">— Sélectionner —</option>
          {pisciculteurs.map(p => <option key={p.id} value={p.id}>{p.prenom} {p.nom}</option>)}
        </Select>
      </Field>
      <Field label="Type de cage"><Select value={f.type} onChange={set("type")}>{CAGE_TYPES.map(t => <option key={t} value={t}>{CAGE_LABELS[t]}</option>)}</Select></Field>
      <Field label="Nombre de cages"><TextInput type="number" min="1" value={f.nombre} onChange={set("nombre")} /></Field>
      <Field label="Nombre d'alevins"><TextInput type="number" min="0" value={f.nombreAlevins} onChange={set("nombreAlevins")} /></Field>
      <Field label="Taille / poids des alevins"><TextInput placeholder="ex. 5-8 g" value={f.tailleAlevins} onChange={set("tailleAlevins")} /></Field>
      <Field label="Date d'empoissonnement"><TextInput type="date" value={f.dateEmpoissonnement || ""} onChange={set("dateEmpoissonnement")} /></Field>
      <Field label="Date de récolte prévue"><TextInput type="date" value={f.dateRecolte || ""} onChange={set("dateRecolte")} /></Field>
      <Field label="Statut"><Select value={f.statut} onChange={set("statut")}>{STATUTS.map(s => <option key={s}>{s}</option>)}</Select></Field>
      <div className="flex gap-2 mt-3">
        <Button onClick={handleSave} disabled={busy} style={{ flex: 1, justifyContent: "center" }}>{busy ? "…" : "Enregistrer"}</Button>
        <Button variant="ghost" onClick={onClose} style={{ flex: 1, justifyContent: "center" }}>Annuler</Button>
      </div>
    </Modal>
  );
}

/* ---------- organisations ---------- */
function OrganisationsModule({ list, onSave, onDelete }) {
  const [editing, setEditing] = useState(null);
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h2 style={{ fontFamily: "'Fraunces', serif", color: C.deep, fontSize: 22 }}>Organisations</h2>
        <Button onClick={() => setEditing({})}><Plus size={16} /> Ajouter</Button>
      </div>
      {list.map(o => (
        <div key={o.id} style={{ background: "#fff", borderRadius: 12, padding: 14, marginBottom: 10, border: `1px solid ${C.line}` }}>
          <div className="flex items-center justify-between">
            <div>
              <div style={{ fontWeight: 600 }}>{o.nom}</div>
              <div style={{ fontSize: 12.5, color: C.mid }}><MapPin size={11} style={{ display: "inline", marginRight: 4 }} />{o.localite || "—"}</div>
              <div style={{ fontSize: 12.5, color: C.mid }}>{o.membres || 0} membres · Responsable : {o.responsable || "—"}</div>
              <div style={{ fontSize: 12.5, color: C.mid }}>{o.contact || "—"}</div>
            </div>
            <div className="flex flex-col gap-2">
              <button onClick={() => setEditing(o)} style={{ background: "none", border: "none", cursor: "pointer" }}><Pencil size={16} color={C.mid} /></button>
              <button onClick={() => onDelete(o.id)} style={{ background: "none", border: "none", cursor: "pointer" }}><Trash2 size={16} color={C.red} /></button>
            </div>
          </div>
        </div>
      ))}
      {list.length === 0 && <Empty />}
      {editing && (
        <Modal title={editing.id ? "Modifier l'organisation" : "Ajouter une organisation"} onClose={() => setEditing(null)}>
          <OrgForm initial={editing} onSave={async (o) => { await onSave(o); setEditing(null); }} onClose={() => setEditing(null)} />
        </Modal>
      )}
    </div>
  );
}
function OrgForm({ initial, onSave, onClose }) {
  const [f, setF] = useState({ nom: "", localite: "", membres: "", responsable: "", contact: "", ...initial });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  async function handleSave() { if (!f.nom) return; setBusy(true); await onSave(f); setBusy(false); }
  return (
    <>
      <Field label="Nom de l'organisation"><TextInput value={f.nom} onChange={set("nom")} /></Field>
      <Field label="Localité"><TextInput value={f.localite} onChange={set("localite")} /></Field>
      <Field label="Nombre de membres"><TextInput type="number" value={f.membres} onChange={set("membres")} /></Field>
      <Field label="Responsable"><TextInput value={f.responsable} onChange={set("responsable")} /></Field>
      <Field label="Contact"><TextInput value={f.contact} onChange={set("contact")} /></Field>
      <div className="flex gap-2 mt-3">
        <Button onClick={handleSave} disabled={busy} style={{ flex: 1, justifyContent: "center" }}>{busy ? "…" : "Enregistrer"}</Button>
        <Button variant="ghost" onClick={onClose} style={{ flex: 1, justifyContent: "center" }}>Annuler</Button>
      </div>
    </>
  );
}

/* ---------- statistics ---------- */
function StatsModule({ pisciculteurs, cages, organisations }) {
  const byOrg = organisations.map(o => ({ nom: o.nom, n: pisciculteurs.filter(p => p.organisation === o.nom).length }));
  const totalAlevins = cages.reduce((s, c) => s + Number(c.nombre_alevins || 0), 0);
  const byType = CAGE_TYPES.map(t => ({ type: CAGE_LABELS[t], n: cages.filter(c => c.type === t).reduce((s, c) => s + Number(c.nombre || 0), 0) }));
  const byMonth = Array(12).fill(0);
  cages.forEach(c => { if (c.statut === "Récoltée" && c.date_recolte) { const m = new Date(c.date_recolte).getMonth(); if (!isNaN(m)) byMonth[m] += Number(c.nombre || 0); } });
  const maxMonth = Math.max(1, ...byMonth);
  return (
    <div>
      <h2 style={{ fontFamily: "'Fraunces', serif", color: C.deep, fontSize: 22, marginBottom: 14 }}>Statistiques</h2>
      <div className="flex flex-wrap gap-3 mb-5">
        <StatCard label="Total alevins" value={totalAlevins} />
        <StatCard label="Cages par type" value={cages.length} sub="enregistrements" />
      </div>
      <SectionCard title="Pisciculteurs par organisation">
        {byOrg.length === 0 && <Empty />}
        {byOrg.map(b => <Bar key={b.nom} label={b.nom} value={b.n} max={Math.max(1, ...byOrg.map(x => x.n))} />)}
      </SectionCard>
      <SectionCard title="Cages par type">
        {byType.map(b => <Bar key={b.type} label={b.type} value={b.n} max={Math.max(1, ...byType.map(x => x.n))} />)}
      </SectionCard>
      <SectionCard title="Récoltes par mois">
        <div className="flex items-end gap-1" style={{ height: 90 }}>
          {byMonth.map((v, i) => (
            <div key={i} style={{ flex: 1, textAlign: "center" }}>
              <div style={{ height: `${(v / maxMonth) * 70}px`, background: C.accent, borderRadius: 3, minHeight: v ? 3 : 0 }} />
              <div style={{ fontSize: 9, color: C.mid, marginTop: 3 }}>{MONTHS_FR[i]}</div>
            </div>
          ))}
        </div>
      </SectionCard>
      <div className="flex gap-2 mb-2">
        <Button variant="dark" style={{ flex: 1, justifyContent: "center" }} onClick={() => exportCSV("pisciculteurs.csv", pisciculteurs)}><Download size={15} /> Export pisciculteurs</Button>
        <Button variant="dark" style={{ flex: 1, justifyContent: "center" }} onClick={() => exportCSV("cages.csv", cages)}><Download size={15} /> Export cages</Button>
      </div>
      <p style={{ fontSize: 11.5, color: C.mid, opacity: 0.75, marginBottom: 20 }}>L'export produit un fichier CSV (compatible Excel). La génération PDF nécessite un service serveur additionnel.</p>
    </div>
  );
}

/* ---------- settings ---------- */
function SettingsModule({ journal }) {
  return (
    <div>
      <h2 style={{ fontFamily: "'Fraunces', serif", color: C.deep, fontSize: 22, marginBottom: 14 }}>Paramètres</h2>
      <SectionCard title="Gestion des utilisateurs">
        <p style={{ fontSize: 13, color: C.mid }}>Chaque pisciculteur se connecte avec son propre identifiant et mot de passe (créés depuis le module Pisciculteurs). Le compte administrateur se gère depuis le tableau de bord Supabase (Authentication → Users).</p>
      </SectionCard>
      <SectionCard title="Sauvegarde">
        <p style={{ fontSize: 13, color: C.mid }}>Toutes les données sont stockées sur Supabase (base PostgreSQL hébergée), avec sauvegardes automatiques gérées par Supabase.</p>
      </SectionCard>
      <SectionCard title="Journal des modifications">
        {journal.length === 0 && <Empty />}
        {journal.map(j => (
          <div key={j.id} style={{ fontSize: 12.5, padding: "5px 0", borderBottom: `1px solid ${C.line}` }}>
            <span style={{ color: C.mid, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11 }}>{new Date(j.created_at).toLocaleString("fr-FR")}</span><br />{j.text}
          </div>
        ))}
      </SectionCard>
    </div>
  );
}
